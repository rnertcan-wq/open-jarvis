package com.firsatavcisi.app.alert

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationManagerCompat

class DismissAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        context.stopService(Intent(context, AlertService::class.java))
        NotificationManagerCompat.from(context).cancel(7101)
    }
}
