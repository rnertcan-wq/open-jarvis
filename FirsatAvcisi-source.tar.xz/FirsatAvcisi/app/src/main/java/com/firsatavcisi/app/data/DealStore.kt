package com.firsatavcisi.app.data

import android.content.Context
import org.json.JSONArray
import java.util.LinkedHashSet

object DealStore {
    private const val PREFS = "firsat_avcisi_local"
    private const val KEY_GROUP = "group_name"
    private const val KEY_HISTORY = "history_json"
    private const val KEY_SEEN = "seen_ids"
    private const val KEY_VOICE = "voice_enabled"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun groupName(context: Context): String = prefs(context).getString(KEY_GROUP, "Onual") ?: "Onual"

    fun setGroupName(context: Context, value: String) {
        prefs(context).edit().putString(KEY_GROUP, value.trim().ifBlank { "Onual" }).apply()
    }

    fun voiceEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_VOICE, true)

    fun setVoiceEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_VOICE, enabled).apply()
    }

    @Synchronized
    fun addDeal(context: Context, deal: Deal): Boolean {
        val p = prefs(context)
        val seen = LinkedHashSet(p.getStringSet(KEY_SEEN, emptySet()) ?: emptySet())
        if (deal.id in seen) return false
        seen.add(deal.id)
        while (seen.size > 500) seen.remove(seen.first())

        val old = JSONArray(p.getString(KEY_HISTORY, "[]") ?: "[]")
        val next = JSONArray()
        val start = (old.length() - 99).coerceAtLeast(0)
        for (i in start until old.length()) next.put(old.getJSONObject(i))
        next.put(deal.toJson())
        p.edit().putStringSet(KEY_SEEN, seen).putString(KEY_HISTORY, next.toString()).apply()
        return true
    }

    fun history(context: Context): List<Deal> {
        val json = JSONArray(prefs(context).getString(KEY_HISTORY, "[]") ?: "[]")
        return buildList {
            for (i in json.length() - 1 downTo 0) {
                val deal = runCatching { Deal.fromJson(json.getJSONObject(i)) }.getOrNull()
                if (deal != null) add(deal)
            }
        }
    }

    fun lastDeal(context: Context): Deal? = history(context).firstOrNull()
}
