package com.firsatavcisi.app.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.firsatavcisi.app.MainActivity
import com.firsatavcisi.app.R
import com.firsatavcisi.app.alert.DismissAlarmReceiver
import com.firsatavcisi.app.data.Deal

object NotificationHelper {
    const val CHANNEL_NORMAL = "firsat_normal"
    const val CHANNEL_URGENT = "firsat_urgent"
    const val CHANNEL_SERVICE = "firsat_service"

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)

        val normal = NotificationChannel(
            CHANNEL_NORMAL,
            "Fırsat bildirimleri",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Onual grubundan yakalanan normal fırsatlar" }

        val urgent = NotificationChannel(
            CHANNEL_URGENT,
            "Acil fırsat alarmları",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "%70 ve üzeri indirimlerde acil uyarı"
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 700, 250, 700, 250, 900)
            setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
        }

        val service = NotificationChannel(
            CHANNEL_SERVICE,
            "Aktif fırsat alarmı",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Kapatılana kadar çalışan fırsat alarmı"
            setSound(null, null)
            enableVibration(false)
        }
        manager.createNotificationChannel(normal)
        manager.createNotificationChannel(urgent)
        manager.createNotificationChannel(service)
    }

    fun showNormal(context: Context, deal: Deal) {
        createChannels(context)
        val openIntent = PendingIntent.getActivity(
            context,
            deal.id.hashCode(),
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_NORMAL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Yeni fırsat yakalandı")
            .setContentText(deal.productName)
            .setStyle(NotificationCompat.BigTextStyle().bigText(summary(deal)))
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(deal.id.hashCode(), notification) }
    }

    fun showUrgentFallback(context: Context, deal: Deal) {
        createChannels(context)
        val dismiss = PendingIntent.getBroadcast(
            context,
            7102,
            Intent(context, DismissAlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            context,
            7103,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_URGENT)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(if (deal.priority == 2) "ÇOK YÜKSEK İNDİRİM!" else "ACİL FIRSAT!")
            .setContentText(deal.productName)
            .setStyle(NotificationCompat.BigTextStyle().bigText(summary(deal)))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(open)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Alarmı kapat", dismiss)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(7101, notification) }
    }

    fun serviceNotification(context: Context, deal: Deal) = NotificationCompat.Builder(context, CHANNEL_SERVICE)
        .setSmallIcon(android.R.drawable.ic_dialog_alert)
        .setContentTitle("Fırsat alarmı aktif")
        .setContentText(deal.productName)
        .setStyle(NotificationCompat.BigTextStyle().bigText(summary(deal)))
        .setCategory(NotificationCompat.CATEGORY_SERVICE)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .addAction(
            android.R.drawable.ic_menu_close_clear_cancel,
            "Alarmı kapat",
            PendingIntent.getBroadcast(
                context,
                7102,
                Intent(context, DismissAlarmReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
        .build()

    private fun summary(deal: Deal): String = buildString {
        append(deal.productName)
        deal.currentPrice?.let { append("\nFiyat: ${formatPrice(it)}") }
        deal.discountPercent?.let { append("\nİndirim: %${"%.1f".format(it)}") }
        deal.url?.let { append("\n$it") }
    }

    private fun formatPrice(value: Double): String =
        String.format(java.util.Locale("tr", "TR"), "%.2f TL", value).replace(",00 TL", " TL")
}
