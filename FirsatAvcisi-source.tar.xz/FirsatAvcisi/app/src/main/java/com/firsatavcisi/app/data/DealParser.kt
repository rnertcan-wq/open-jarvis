package com.firsatavcisi.app.data

import java.security.MessageDigest
import java.util.Locale

object DealParser {
    private val urlRegex = Regex("""https?://[^\s<>\[\]()]+|(?:www\.)?onu\.al/[^\s<>\[\]()]+""", RegexOption.IGNORE_CASE)
    private val priceRegex = Regex(
        """(?<![\d])([0-9]{1,3}(?:[.\s][0-9]{3})*(?:,[0-9]{1,2})?|[0-9]+(?:,[0-9]{1,2})?)\s*(?:₺|TL)(?![A-Za-z])""",
        RegexOption.IGNORE_CASE
    )
    private val binPriceRegex = Regex("""(?<![\d])([0-9]+(?:[.,][0-9]+)?)\s*(?:bin|k)\s*TL""", RegexOption.IGNORE_CASE)
    private val discountRegex = Regex("""(?:%\s*([0-9]{1,3}(?:[.,][0-9]+)?)|([0-9]{1,3}(?:[.,][0-9]+)?)\s*%)""")

    fun parse(message: String, title: String, conversationTitle: String, configuredGroup: String): Deal {
        val urls = urlRegex.findAll(message).map { cleanUrl(it.value) }.filter { it.isNotBlank() }.toList()
        val prices = parsePrices(message)
        val currentPrice = prices.minOrNull()
        val oldPrice = prices.maxOrNull()?.takeIf { prices.size >= 2 && it != currentPrice }
        val explicitDiscount = discountRegex.find(message)?.let { match ->
            (match.groupValues.getOrNull(1)?.takeIf { it.isNotBlank() }
                ?: match.groupValues.getOrNull(2)?.takeIf { it.isNotBlank() })
                ?.replace(',', '.')?.toDoubleOrNull()
        }
        val calculatedDiscount = if (oldPrice != null && currentPrice != null && oldPrice > 0.0) {
            ((oldPrice - currentPrice) / oldPrice * 100.0).coerceIn(0.0, 100.0)
        } else null
        val discount = explicitDiscount ?: calculatedDiscount

        val priority = when {
            currentPrice != null && currentPrice <= 100.0 && discount != null && discount >= 90.0 -> 2
            discount != null && discount >= 70.0 -> 1
            else -> 0
        }

        val productName = buildProductName(message, title, conversationTitle, configuredGroup)
        val stableKey = urls.firstOrNull() ?: "${productName.lowercase(Locale.ROOT)}|${currentPrice ?: "?"}|${discount ?: "?"}"
        val id = sha256(stableKey).take(32)

        return Deal(
            id = id,
            productName = productName,
            currentPrice = currentPrice,
            oldPrice = oldPrice,
            discountPercent = discount,
            url = urls.firstOrNull(),
            rawMessage = message.take(2000),
            groupName = conversationTitle.ifBlank { configuredGroup },
            createdAt = System.currentTimeMillis(),
            priority = priority
        )
    }

    private fun parsePrices(text: String): List<Double> {
        val values = mutableListOf<Double>()
        priceRegex.findAll(text).forEach { match ->
            normalizeTurkishNumber(match.groupValues[1])?.let(values::add)
        }
        binPriceRegex.findAll(text).forEach { match ->
            normalizeTurkishNumber(match.groupValues[1])?.let { values.add(it * 1000.0) }
        }
        return values.filter { it >= 0.01 && it <= 100_000_000.0 }.distinct()
    }

    private fun normalizeTurkishNumber(value: String): Double? {
        val compact = value.replace(" ", "")
        val normalized = if (compact.contains(',')) {
            compact.replace(".", "").replace(',', '.')
        } else {
            compact.replace(".", "")
        }
        return normalized.toDoubleOrNull()
    }

    private fun buildProductName(message: String, title: String, conversationTitle: String, group: String): String {
        val cleaned = urlRegex.replace(message, " ")
            .replace(priceRegex, " ")
            .replace(binPriceRegex, " ")
            .replace(discountRegex, " ")
            .replace(Regex("(?i)\\b(indirim|fırsat|firsat|son stok|kaçırma|kacirma|onual)\\b"), " ")
            .replace(Regex("[🔥⚡️🚨🎉🛒💥➡️⬇️⬆️]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim(' ', '-', ':', '>', '|')
        val candidate = cleaned.ifBlank { title.takeIf { it.isNotBlank() && !it.contains(group, true) } ?: conversationTitle }
        return candidate.ifBlank { "Yeni fırsat" }.take(100)
    }

    private fun cleanUrl(raw: String): String = raw.trim().trimEnd('.', ',', ';', ')', ']', '}', '>', '!', '?')
        .let { if (it.startsWith("www.", true)) "https://$it" else it }

    private fun sha256(input: String): String = MessageDigest.getInstance("SHA-256")
        .digest(input.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
