package com.firsatavcisi.app.alert

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.tts.TextToSpeech
import androidx.core.content.ContextCompat
import com.firsatavcisi.app.data.DealStore
import com.firsatavcisi.app.notifications.NotificationHelper
import java.util.Locale

class AlertService : Service() {
    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null
    private var tts: TextToSpeech? = null
    private var toneGenerator: ToneGenerator? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        runCatching { ringtone?.stop() }
        runCatching { vibrator?.cancel() }
        runCatching { tts?.stop() }
        val product = intent?.getStringExtra(EXTRA_PRODUCT) ?: "Yeni fırsat"
        val price = intent?.getStringExtra(EXTRA_PRICE).orEmpty()
        val discount = intent?.getStringExtra(EXTRA_DISCOUNT).orEmpty()
        val priority = intent?.getIntExtra(EXTRA_PRIORITY, 1) ?: 1
        val url = intent?.getStringExtra(EXTRA_URL).orEmpty()

        val deal = com.firsatavcisi.app.data.Deal(
            id = "active-alert",
            productName = product,
            currentPrice = price.toDoubleOrNull(),
            oldPrice = null,
            discountPercent = discount.toDoubleOrNull(),
            url = url.ifBlank { null },
            rawMessage = "",
            groupName = "Onual",
            createdAt = System.currentTimeMillis(),
            priority = priority
        )

        NotificationHelper.createChannels(this)
        val notification = NotificationHelper.serviceNotification(this, deal)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        startRinging()
        startVibration()
        if (DealStore.voiceEnabled(this) && isBluetoothAudioConnected()) {
            speak("Onual grubunda ${if (priority == 2) "çok yüksek indirimli" else "acil"} bir fırsat bulundu. $product. ${price.ifBlank { "Fiyat doğrulanamadı" }}. İndirim ${discount.ifBlank { "doğrulanamadı" }}. Fırsatı açmak için Fırsat Avcısı uygulamasını kullanın.")
        }
        return START_NOT_STICKY
    }

    private fun startRinging() {
        runCatching {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ringtone = RingtoneManager.getRingtone(this, uri)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) ringtone?.isLooping = true
            ringtone?.play()
        }.onFailure {
            runCatching {
                toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 90).apply {
                    startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 60_000)
                }
            }
        }
    }

    private fun startVibration() {
        runCatching {
            vibrator = getSystemService(Vibrator::class.java)
            val pattern = longArrayOf(0, 700, 250, 700, 250, 1000)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, 0)
            }
        }
    }

    private fun isBluetoothAudioConnected(): Boolean {
        val audioManager = getSystemService(AudioManager::class.java)
        return audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { device ->
            device.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                device.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && device.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
        }
    }

    private fun speak(text: String) {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                tts?.language = Locale("tr", "TR")
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "firsat-alert")
            }
        }
    }

    override fun onDestroy() {
        runCatching { ringtone?.stop() }
        runCatching { toneGenerator?.stopTone() }
        runCatching { toneGenerator?.release() }
        runCatching { vibrator?.cancel() }
        runCatching { tts?.stop(); tts?.shutdown() }
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 7100
        private const val EXTRA_PRODUCT = "product"
        private const val EXTRA_PRICE = "price"
        private const val EXTRA_DISCOUNT = "discount"
        private const val EXTRA_PRIORITY = "priority"
        private const val EXTRA_URL = "url"

        fun start(context: Context, deal: com.firsatavcisi.app.data.Deal) {
            val intent = Intent(context, AlertService::class.java).apply {
                putExtra(EXTRA_PRODUCT, deal.productName)
                putExtra(EXTRA_PRICE, deal.currentPrice?.toString().orEmpty())
                putExtra(EXTRA_DISCOUNT, deal.discountPercent?.toString().orEmpty())
                putExtra(EXTRA_PRIORITY, deal.priority)
                putExtra(EXTRA_URL, deal.url.orEmpty())
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, AlertService::class.java))
        }
    }
}
