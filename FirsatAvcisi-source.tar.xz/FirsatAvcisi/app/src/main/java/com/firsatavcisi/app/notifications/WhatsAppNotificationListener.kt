package com.firsatavcisi.app.notifications

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.firsatavcisi.app.alert.AlertService
import com.firsatavcisi.app.data.DealParser
import com.firsatavcisi.app.data.DealStore

class WhatsAppNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (sbn.packageName != WHATSAPP_PACKAGE && sbn.packageName != WHATSAPP_BUSINESS_PACKAGE) return

        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val conversationTitle = extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.joinToString("\n") { it.toString() }
            .orEmpty()
        val message = sequenceOf(bigText, lines, text)
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString("\n")
            .take(4000)
        if (message.isBlank()) return

        val groupName = DealStore.groupName(this)
        val groupMatch = conversationTitle.contains(groupName, ignoreCase = true) ||
            title.contains(groupName, ignoreCase = true) ||
            (sbn.tag?.contains(groupName, ignoreCase = true) == true)
        if (!groupMatch) return

        val deal = DealParser.parse(message, title, conversationTitle, groupName)
        if (!DealStore.addDeal(this, deal)) return

        if (deal.priority >= 1) {
            runCatching { AlertService.start(this, deal) }
                .onFailure { NotificationHelper.showUrgentFallback(this, deal) }
        } else {
            NotificationHelper.showNormal(this, deal)
        }
    }

    companion object {
        private const val WHATSAPP_PACKAGE = "com.whatsapp"
        private const val WHATSAPP_BUSINESS_PACKAGE = "com.whatsapp.w4b"
    }
}
