package com.firsatavcisi.app

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.app.NotificationManagerCompat
import com.firsatavcisi.app.alert.AlertService
import com.firsatavcisi.app.data.Deal
import com.firsatavcisi.app.data.DealStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF0B1220)
private val Panel = Color(0xFF141F32)
private val PanelLight = Color(0xFF1C2A40)
private val Mint = Color(0xFF42D6A4)
private val Amber = Color(0xFFFFC46B)
private val Muted = Color(0xFF9AA9BC)

class MainActivity : ComponentActivity() {
    var listenerEnabled by mutableStateOf(false)
        private set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        refreshListenerState()
        setContent {
            FirsatAvcisiApp(
                listenerEnabled = listenerEnabled,
                onRefreshListener = { refreshListenerState() }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        refreshListenerState()
    }

    private fun refreshListenerState() {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        listenerEnabled = enabled
    }
}

@Composable
private fun FirsatAvcisiApp(listenerEnabled: Boolean, onRefreshListener: () -> Unit) {
    val context = LocalContext.current
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var deals by remember { mutableStateOf(DealStore.history(context)) }
    var groupName by remember { mutableStateOf(DealStore.groupName(context)) }
    var voiceEnabled by remember { mutableStateOf(DealStore.voiceEnabled(context)) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        Toast.makeText(context, if (granted) "Bildirim izni verildi" else "Bildirim izni verilmedi", Toast.LENGTH_SHORT).show()
    }
    val audioPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) Toast.makeText(context, "Sesli komut için mikrofon izni gerekiyor", Toast.LENGTH_SHORT).show()
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            handleVoiceCommand(context, spoken, deals.firstOrNull())
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Mint,
            secondary = Amber,
            background = Navy,
            surface = Panel,
            onPrimary = Navy,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(
                    containerColor = Panel,
                    contentColor = Color.White,
                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Home, contentDescription = null) },
                        label = { Text("Ana sayfa") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { deals = DealStore.history(context); selectedTab = 1 },
                        icon = { Icon(Icons.Default.History, contentDescription = null) },
                        label = { Text("Fırsatlar") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        label = { Text("Ayarlar") }
                    )
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> HomeScreen(
                    modifier = Modifier.padding(padding),
                    listenerEnabled = listenerEnabled,
                    deals = deals,
                    onEnableTracking = {
                        runCatching { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
                    },
                    onRefresh = {
                        onRefreshListener()
                        deals = DealStore.history(context)
                    },
                    onOpenLast = { deals.firstOrNull()?.url?.let { openUrl(context, it) } },
                    onVoice = {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            launchSpeech(context, speechLauncher)
                        } else {
                            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    onRequestNotificationPermission = {
                        if (Build.VERSION.SDK_INT >= 33) notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        else Toast.makeText(context, "Bildirim ayarlarını telefon ayarlarından kontrol et", Toast.LENGTH_SHORT).show()
                    },
                    onStopAlarm = {
                        AlertService.stop(context)
                        NotificationManagerCompat.from(context).cancel(7101)
                        Toast.makeText(context, "Alarm kapatıldı", Toast.LENGTH_SHORT).show()
                    }
                )
                1 -> DealListScreen(
                    modifier = Modifier.padding(padding),
                    deals = deals,
                    onOpen = { it.url?.let { url -> openUrl(context, url) } }
                )
                else -> SettingsScreen(
                    modifier = Modifier.padding(padding),
                    groupName = groupName,
                    onGroupNameChange = { groupName = it },
                    onSaveGroup = {
                        DealStore.setGroupName(context, groupName)
                        Toast.makeText(context, "Grup adı kaydedildi", Toast.LENGTH_SHORT).show()
                    },
                    voiceEnabled = voiceEnabled,
                    onVoiceChange = {
                        voiceEnabled = it
                        DealStore.setVoiceEnabled(context, it)
                    },
                    listenerEnabled = listenerEnabled,
                    onOpenListenerSettings = {
                        runCatching { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
                    }
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    listenerEnabled: Boolean,
    deals: List<Deal>,
    onEnableTracking: () -> Unit,
    onRefresh: () -> Unit,
    onOpenLast: () -> Unit,
    onVoice: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onStopAlarm: () -> Unit
) {
    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(48.dp).background(Mint.copy(alpha = 0.14f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.LocalOffer, contentDescription = null, tint = Mint, modifier = Modifier.size(27.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("FIRSAT AVCISI", fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                Text("Onual fırsat takipçisi", color = Muted, fontSize = 12.sp)
            }
            Surface(color = if (listenerEnabled) Mint.copy(alpha = 0.14f) else Amber.copy(alpha = 0.14f), shape = CircleShape) {
                Text(
                    if (listenerEnabled) "TAKİP AÇIK" else "KURULUM GEREKİYOR",
                    color = if (listenerEnabled) Mint else Amber,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                )
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.NotificationsActive, tint = Mint, contentDescription = null, modifier = Modifier.size(25.dp))
                    Spacer(Modifier.width(9.dp))
                    Text("Canlı takip sistemi", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
                Text(
                    if (listenerEnabled) "WhatsApp bildirim erişimi açık. Onual grup mesajları geldiğinde fırsat analizi yapılır."
                    else "WhatsApp mesajlarını okuyabilmek için bildirim erişimini etkinleştirmen gerekiyor.",
                    color = Muted,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
                Button(
                    onClick = if (listenerEnabled) onRefresh else onEnableTracking,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Navy),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(if (listenerEnabled) "Durumu yenile" else "WhatsApp takibini etkinleştir", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(onClick = onRequestNotificationPermission, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Bildirim iznini kontrol et")
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Yakalanan", deals.size.toString(), Icons.Default.History, Modifier.weight(1f))
            MetricCard("Acil fırsat", deals.count { it.priority >= 1 }.toString(), Icons.Default.NotificationsActive, Modifier.weight(1f))
        }

        Card(colors = CardDefaults.cardColors(containerColor = PanelLight), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("FIRSAT KURALLARI", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                RuleRow("≤100 TL ve ≥%90", "Çok yüksek öncelik alarmı", Mint)
                Divider(color = Color.White.copy(alpha = 0.08f))
                RuleRow("≥%70 indirim", "Arama benzeri ses + titreşim", Amber)
                Divider(color = Color.White.copy(alpha = 0.08f))
                RuleRow("%70 altı", "Sessiz geçmiş kaydı", Muted)
                Text("Otomatik satın alma yok. Uygulama yalnızca fırsatları yakalar ve bildirir.", color = Muted, fontSize = 11.sp)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onVoice,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = PanelLight),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Mic, contentDescription = null)
                Spacer(Modifier.width(7.dp))
                Text("Sesli komut")
            }
            OutlinedButton(onClick = onStopAlarm, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                Text("Alarmı kapat")
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Son yakalanan fırsat", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null); Text("Yenile") }
                }
                val last = deals.firstOrNull()
                if (last == null) {
                    Text("Henüz fırsat yakalanmadı. Onual grubundan yeni bir mesaj bekleniyor.", color = Muted, fontSize = 13.sp)
                } else {
                    DealSummary(last, onClick = onOpenLast)
                }
            }
        }
        Text("Gizlilik: Mesaj analizi ve geçmiş kayıtları bu telefonda tutulur. Harici sunucuya gönderim yapılmaz.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun MetricCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, contentDescription = null, tint = Mint, modifier = Modifier.size(21.dp))
            Text(value, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun RuleRow(title: String, subtitle: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(color, CircleShape))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun DealListScreen(modifier: Modifier, deals: List<Deal>, onOpen: (Deal) -> Unit) {
    Column(modifier = modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Yakalanan fırsatlar", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Son 100 fırsat bu cihazda saklanır.", color = Muted, fontSize = 12.sp)
        if (deals.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Henüz kayıt yok", color = Muted)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(deals, key = { it.id }) { deal ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpen(deal) },
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(deal.productName, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                PriorityPill(deal.priority)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(deal.currentPrice?.let(::formatPrice) ?: "Fiyat doğrulanamadı", color = Mint, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(9.dp))
                                deal.discountPercent?.let { Text("%${formatPercent(it)} indirim", color = Amber, fontSize = 12.sp) }
                            }
                            Text(formatDate(deal.createdAt), color = Muted, fontSize = 11.sp)
                            if (!deal.url.isNullOrBlank()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Link, contentDescription = null, tint = Muted, modifier = Modifier.size(14.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(deal.url, color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PriorityPill(priority: Int) {
    val color = when (priority) { 2 -> Mint; 1 -> Amber; else -> Muted }
    val text = when (priority) { 2 -> "ÇOK YÜKSEK"; 1 -> "ACİL"; else -> "NORMAL" }
    Surface(color = color.copy(alpha = 0.14f), shape = CircleShape) {
        Text(text, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
    }
}

@Composable
private fun DealSummary(deal: Deal, onClick: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(deal.productName, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            PriorityPill(deal.priority)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(deal.currentPrice?.let(::formatPrice) ?: "Fiyat doğrulanamadı", color = Mint, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            deal.discountPercent?.let { Text("  %${formatPercent(it)} indirim", color = Amber, fontSize = 12.sp) }
        }
        Text(formatDate(deal.createdAt), color = Muted, fontSize = 11.sp)
        if (!deal.url.isNullOrBlank()) {
            OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                Icon(Icons.Default.Link, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(7.dp))
                Text("Ürün bağlantısını aç")
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    modifier: Modifier,
    groupName: String,
    onGroupNameChange: (String) -> Unit,
    onSaveGroup: () -> Unit,
    voiceEnabled: Boolean,
    onVoiceChange: (Boolean) -> Unit,
    listenerEnabled: Boolean,
    onOpenListenerSettings: () -> Unit
) {
    Column(modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Text("Ayarlar", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                Text("WhatsApp grup takibi", fontWeight = FontWeight.Bold)
                Text("Takip edilecek grup adını WhatsApp'ta göründüğü şekilde yaz.", color = Muted, fontSize = 12.sp)
                OutlinedTextField(
                    value = groupName,
                    onValueChange = onGroupNameChange,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Grup adı") }
                )
                Button(onClick = onSaveGroup, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Navy)) {
                    Text("Grup adını kaydet", fontWeight = FontWeight.Bold)
                }
                Divider(color = Color.White.copy(alpha = 0.08f))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Bildirim erişimi", fontWeight = FontWeight.SemiBold)
                        Text(if (listenerEnabled) "Etkin" else "Etkin değil", color = if (listenerEnabled) Mint else Amber, fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = onOpenListenerSettings) { Text("Aç") }
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Bluetooth'ta sesli anons", fontWeight = FontWeight.Bold)
                        Text("Araç Bluetooth'u bağlıysa fırsat bilgisi sesli okunur.", color = Muted, fontSize = 12.sp)
                    }
                    Switch(checked = voiceEnabled, onCheckedChange = onVoiceChange)
                }
                Divider(color = Color.White.copy(alpha = 0.08f))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Bluetooth, contentDescription = null, tint = Mint)
                    Spacer(Modifier.width(9.dp))
                    Text("Araç modu için Bluetooth ses çıkışı kullanılır.", color = Muted, fontSize = 12.sp)
                }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = Mint)
                    Spacer(Modifier.width(8.dp))
                    Text("Gizlilik ve çalışma şekli", fontWeight = FontWeight.Bold)
                }
                Text(
                    "Uygulama yalnızca WhatsApp bildirimlerinde görünen içeriği okur. Mesajları sunucuya göndermez. Grup bildirimleri açık olmalı ve mesaj önizlemesi gizlenmemelidir. Fiyat veya indirim metinde yoksa oran uydurulmaz; fırsat doğrulanamadı olarak kaydedilir.",
                    color = Muted,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

private fun launchSpeech(context: Context, launcher: androidx.activity.result.ActivityResultLauncher<Intent>) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Fırsat Avcısı komutunu söyle")
    }
    runCatching { launcher.launch(intent) }
        .onFailure { Toast.makeText(context, "Bu cihazda sesli komut hizmeti bulunamadı", Toast.LENGTH_SHORT).show() }
}

private fun handleVoiceCommand(context: Context, spoken: String, lastDeal: Deal?) {
    val command = spoken.lowercase(Locale("tr", "TR"))
    when {
        "alarmı kapat" in command || "alarmı durdur" in command -> {
            AlertService.stop(context)
            NotificationManagerCompat.from(context).cancel(7101)
            Toast.makeText(context, "Alarm kapatıldı", Toast.LENGTH_SHORT).show()
        }
        "fırsatı aç" in command || "linki aç" in command || "ürünü aç" in command -> {
            val url = lastDeal?.url
            if (url != null) openUrl(context, url) else Toast.makeText(context, "Açılacak fırsat bağlantısı yok", Toast.LENGTH_SHORT).show()
        }
        "tekrar oku" in command || "tekrar et" in command -> {
            val deal = lastDeal
            if (deal != null) speakOnce(context, "Son fırsat: ${deal.productName}. Fiyat ${deal.currentPrice?.let(::formatPrice) ?: "bilinmiyor"}. İndirim ${deal.discountPercent?.let { "%${formatPercent(it)}" } ?: "bilinmiyor"}.")
        }
        "geç" in command || "atla" in command -> Toast.makeText(context, "Son fırsat geçildi", Toast.LENGTH_SHORT).show()
        else -> Toast.makeText(context, "Komut anlaşılamadı: $spoken", Toast.LENGTH_SHORT).show()
    }
}

private fun speakOnce(context: Context, text: String) {
    var engine: TextToSpeech? = null
    engine = TextToSpeech(context) { status ->
        if (status == TextToSpeech.SUCCESS) {
            engine?.language = Locale("tr", "TR")
            engine?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "firsat-repeat")
        }
    }
}

private fun openUrl(context: Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        .onFailure { Toast.makeText(context, "Bağlantı açılamadı", Toast.LENGTH_SHORT).show() }
}

private fun formatPrice(value: Double): String = String.format(Locale("tr", "TR"), "%.2f TL", value).replace(",00 TL", " TL")
private fun formatPercent(value: Double): String = String.format(Locale("tr", "TR"), "%.1f", value).removeSuffix(",0")
private fun formatDate(timestamp: Long): String = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr", "TR")).format(Date(timestamp))
