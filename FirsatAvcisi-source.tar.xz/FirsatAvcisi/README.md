# Fırsat Avcısı (Android)

Onual WhatsApp grubunda görünen fırsat mesajlarını Android bildirimlerinden yerel olarak yakalayan, fiyat/indirim metnini analiz eden ve fırsatları önem derecesine göre bildiren Android uygulaması.

## Kurallar

- Ürün fiyatı 100 TL veya altındaysa ve indirim %90 veya üzerindeyse: çok yüksek öncelikli alarm.
- İndirim %70 veya üzerindeyse: yüksek öncelikli alarm.
- Diğer fırsatlar: sessiz geçmiş kaydı.
- Otomatik satın alma, ödeme, SMS okuma veya mağaza entegrasyonu yoktur.
- Kargo bedeli, ürün fiyatı eşiğinin hesabına katılmaz. Uygulama yalnızca mesajda görünen ürün fiyatını analiz eder.

## Kurulum

1. APK'yı Android telefona yükleyin.
2. Uygulamada **WhatsApp takibini etkinleştir** seçeneğine dokunun.
3. Android Bildirim Erişimi ekranında Fırsat Avcısı'na izin verin.
4. WhatsApp'ta Onual grubunun bildirimlerini açın ve mesaj önizlemesini gizlemeyin.
5. Uygulama Ayarları'ndan grup adının WhatsApp'ta görünen adla aynı olduğunu kontrol edin.
6. Bildirim iznini verin. Araçta sesli anons için Bluetooth ses çıkışını bağlayın ve sesli anons ayarını açık bırakın.

## Sesli komutlar

Ana ekrandaki **Sesli komut** düğmesine dokunup Türkçe olarak şunları söyleyin:

- "Alarmı kapat"
- "Fırsatı aç"
- "Tekrar oku"
- "Geç"

Mikrofon sürekli dinlenmez. Sesli komut, kullanıcı düğmeye bastığında başlar.

## Önemli sınırlamalar

- Uygulama WhatsApp'ın bildirim önizlemesinde görünen metni okuyabilir; sohbet geçmişini doğrudan açıp taramaz.
- WhatsApp bildirimi grup adını göstermiyorsa grup eşleştirmesi yapılamayabilir. Grup bildirimlerinin görünür olduğundan emin olun.
- Fiyat veya indirim yüzdesi mesajda yoksa uygulama oran uydurmaz; fırsatı doğrulanmamış olarak kaydeder.
- Kısa bağlantının hedef sayfası otomatik açılmaz veya mağaza fiyatı sorgulanmaz. Mesajdaki bağlantı kullanıcı tarafından açılır.
- Android/üretici pil yönetimi arka plan bildirim dinleyicisini durdurabilir. HiOS'ta uygulama için pil optimizasyonunu kapatın ve otomatik başlatmaya izin verin.
- Arama benzeri alarm; yüksek öncelikli bildirim, alarm sesi ve titreşim kullanır. Android'in tam ekran arama/alarmlara ilişkin sürüm ve izin kısıtlamaları nedeniyle gerçek GSM araması değildir.

## Gizlilik

Uygulamada INTERNET izni bulunmaz. Mesaj metni, fırsat geçmişi ve ayarlar cihazdaki yerel SharedPreferences alanında tutulur.

## Derleme

GitHub Actions workflow: `.github/workflows/build-firsat-avcisi.yml`

Workflow, `firsat-avcisi` dalına gönderilen değişikliklerde debug APK üretir ve `FirsatAvcisi-debug-apk` adıyla artifact olarak yükler.
